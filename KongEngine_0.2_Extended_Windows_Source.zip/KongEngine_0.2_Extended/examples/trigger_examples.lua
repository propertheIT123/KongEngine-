-- API sketches for the trigger system used by the sample.
-- These examples are illustrative and depend on Trigger being provided by main.lua.

Trigger.After(1.5, function()
    Kong.Log("This event runs after 1.5 seconds")
end)

-- To register a collision trigger in a level script:
-- Trigger.OnEnter(playerId, targetId, function()
--     Kong.SetColor(targetId, 255, 40, 120)
-- end)
