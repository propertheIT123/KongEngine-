#include <SDL.h>
#include <lua.hpp>

#include <algorithm>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

namespace {
struct GameObject {
    int id = 0;
    std::string name;
    float x = 0, y = 0, w = 32, h = 32;
    float vx = 0, vy = 0;
    float r = 60, g = 210, b = 255, a = 255;
    bool solid = false, active = true, gravity = false;
};

SDL_Renderer* renderer = nullptr;
lua_State* L = nullptr;
std::unordered_map<int, GameObject> objects;
int nextId = 1;
float cameraX = 0.0f;
float gravityForce = 1400.0f;

GameObject* FindObject(lua_State* state, int index) {
    const int id = static_cast<int>(luaL_checkinteger(state, index));
    auto it = objects.find(id);
    if (it == objects.end()) {
        luaL_error(state, "Unknown object id: %d", id);
        return nullptr;
    }
    return &it->second;
}

SDL_Scancode KeyFromName(const char* key) {
    if (SDL_strcasecmp(key, "SPACE") == 0) return SDL_SCANCODE_SPACE;
    if (SDL_strcasecmp(key, "LEFT") == 0) return SDL_SCANCODE_LEFT;
    if (SDL_strcasecmp(key, "RIGHT") == 0) return SDL_SCANCODE_RIGHT;
    if (SDL_strcasecmp(key, "UP") == 0) return SDL_SCANCODE_UP;
    if (SDL_strcasecmp(key, "DOWN") == 0) return SDL_SCANCODE_DOWN;
    if (SDL_strcasecmp(key, "A") == 0) return SDL_SCANCODE_A;
    if (SDL_strcasecmp(key, "D") == 0) return SDL_SCANCODE_D;
    if (SDL_strcasecmp(key, "W") == 0) return SDL_SCANCODE_W;
    if (SDL_strcasecmp(key, "S") == 0) return SDL_SCANCODE_S;
    if (SDL_strcasecmp(key, "ESCAPE") == 0) return SDL_SCANCODE_ESCAPE;
    return SDL_SCANCODE_UNKNOWN;
}

void ApiLog(lua_State* s) {
    std::cout << "[Lua] " << luaL_optstring(s, 1, "") << '\n';
}
void ApiInputDown(lua_State* s) {
    SDL_Scancode key = KeyFromName(luaL_checkstring(s, 1));
    const Uint8* state = SDL_GetKeyboardState(nullptr);
    lua_pushboolean(s, key != SDL_SCANCODE_UNKNOWN && state[key] != 0);
}
void ApiCreateObject(lua_State* s) {
    GameObject o;
    o.id = nextId++;
    o.name = luaL_optstring(s, 1, "Object");
    o.x = static_cast<float>(luaL_optnumber(s, 2, 0));
    o.y = static_cast<float>(luaL_optnumber(s, 3, 0));
    o.w = static_cast<float>(luaL_optnumber(s, 4, 32));
    o.h = static_cast<float>(luaL_optnumber(s, 5, 32));
    o.r = static_cast<float>(luaL_optnumber(s, 6, 60));
    o.g = static_cast<float>(luaL_optnumber(s, 7, 210));
    o.b = static_cast<float>(luaL_optnumber(s, 8, 255));
    o.solid = lua_toboolean(s, 9) != 0;
    o.gravity = lua_toboolean(s, 10) != 0;
    objects.emplace(o.id, o);
    lua_pushinteger(s, o.id);
}
void ApiSetPosition(lua_State* s) {
    auto* o = FindObject(s, 1);
    o->x = static_cast<float>(luaL_checknumber(s, 2));
    o->y = static_cast<float>(luaL_checknumber(s, 3));
}
void ApiSetVelocity(lua_State* s) {
    auto* o = FindObject(s, 1);
    o->vx = static_cast<float>(luaL_checknumber(s, 2));
    o->vy = static_cast<float>(luaL_checknumber(s, 3));
}
void ApiSetColor(lua_State* s) {
    auto* o = FindObject(s, 1);
    o->r = std::clamp(static_cast<float>(luaL_checknumber(s, 2)), 0.0f, 255.0f);
    o->g = std::clamp(static_cast<float>(luaL_checknumber(s, 3)), 0.0f, 255.0f);
    o->b = std::clamp(static_cast<float>(luaL_checknumber(s, 4)), 0.0f, 255.0f);
}
void ApiSetSolid(lua_State* s) {
    FindObject(s, 1)->solid = lua_toboolean(s, 2) != 0;
}
void ApiDestroyObject(lua_State* s) {
    objects.erase(static_cast<int>(luaL_checkinteger(s, 1)));
}
void ApiDrawRect(lua_State* s) {
    const int x = static_cast<int>(luaL_checknumber(s, 1));
    const int y = static_cast<int>(luaL_checknumber(s, 2));
    const int w = std::max(0, static_cast<int>(luaL_checknumber(s, 3)));
    const int h = std::max(0, static_cast<int>(luaL_checknumber(s, 4)));
    const Uint8 r = static_cast<Uint8>(std::clamp(static_cast<int>(luaL_optinteger(s, 5, 60)), 0, 255));
    const Uint8 g = static_cast<Uint8>(std::clamp(static_cast<int>(luaL_optinteger(s, 6, 210)), 0, 255));
    const Uint8 b = static_cast<Uint8>(std::clamp(static_cast<int>(luaL_optinteger(s, 7, 255)), 0, 255));
    SDL_SetRenderDrawColor(renderer, r, g, b, 255);
    SDL_Rect rect{x - static_cast<int>(cameraX), y, w, h};
    SDL_RenderFillRect(renderer, &rect);
}
void ApiSetCameraX(lua_State* s) {
    cameraX = static_cast<float>(luaL_checknumber(s, 1));
}
void RegisterApi(lua_State* s) {
    const luaL_Reg api[] = {
        {"Log", ApiLog}, {"InputDown", ApiInputDown},
        {"CreateObject", ApiCreateObject}, {"SetPosition", ApiSetPosition},
        {"SetVelocity", ApiSetVelocity}, {"SetColor", ApiSetColor},
        {"SetSolid", ApiSetSolid}, {"DestroyObject", ApiDestroyObject},
        {"DrawRect", ApiDrawRect}, {"SetCameraX", ApiSetCameraX},
        {nullptr, nullptr}
    };
    luaL_newlib(s, api);
    lua_setglobal(s, "Kong");
}
bool CallLua(const char* name, double dt = 0.0, bool withDt = false) {
    lua_getglobal(L, name);
    if (!lua_isfunction(L, -1)) { lua_pop(L, 1); return true; }
    if (withDt) lua_pushnumber(L, dt);
    if (lua_pcall(L, withDt ? 1 : 0, 0, 0) != LUA_OK) {
        std::cerr << "[Lua error: " << name << "] " << lua_tostring(L, -1) << '\n';
        lua_pop(L, 1);
        return false;
    }
    return true;
}
bool Overlap(const GameObject& a, const GameObject& b) {
    return a.x < b.x + b.w && a.x + a.w > b.x &&
           a.y < b.y + b.h && a.y + a.h > b.y;
}
void UpdatePhysics(float dt) {
    // Simple platform collision: downward landing only.
    for (auto& entry : objects) {
        GameObject& o = entry.second;
        if (!o.active) continue;
        const float oldY = o.y;
        if (o.gravity) o.vy += gravityForce * dt;
        o.x += o.vx * dt;
        o.y += o.vy * dt;
        if (o.gravity && o.vy >= 0.0f) {
            for (const auto& otherEntry : objects) {
                const GameObject& p = otherEntry.second;
                if (p.id == o.id || !p.active || !p.solid) continue;
                const bool horizontal = o.x < p.x + p.w && o.x + o.w > p.x;
                const bool crossedTop = oldY + o.h <= p.y && o.y + o.h >= p.y;
                if (horizontal && crossedTop) { o.y = p.y - o.h; o.vy = 0.0f; break; }
            }
        }
    }
}
void DrawObjects() {
    for (const auto& entry : objects) {
        const GameObject& o = entry.second;
        if (!o.active) continue;
        SDL_SetRenderDrawColor(renderer,
            static_cast<Uint8>(std::clamp(o.r, 0.0f, 255.0f)),
            static_cast<Uint8>(std::clamp(o.g, 0.0f, 255.0f)),
            static_cast<Uint8>(std::clamp(o.b, 0.0f, 255.0f)),
            static_cast<Uint8>(std::clamp(o.a, 0.0f, 255.0f)));
        SDL_Rect rect{static_cast<int>(o.x - cameraX), static_cast<int>(o.y),
                      std::max(1, static_cast<int>(o.w)), std::max(1, static_cast<int>(o.h))};
        SDL_RenderFillRect(renderer, &rect);
    }
}
} // namespace

int main() {
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_EVENTS) != 0) {
        std::cerr << "SDL_Init failed: " << SDL_GetError() << '\n';
        return 1;
    }
    SDL_Window* window = SDL_CreateWindow("KongEngine 0.2 Extended",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 960, 540, SDL_WINDOW_SHOWN);
    if (!window) {
        std::cerr << "Window creation failed: " << SDL_GetError() << '\n';
        SDL_Quit();
        return 1;
    }
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (!renderer) renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_SOFTWARE);
    if (!renderer) {
        std::cerr << "Renderer creation failed: " << SDL_GetError() << '\n';
        SDL_DestroyWindow(window); SDL_Quit(); return 1;
    }

    L = luaL_newstate();
    if (!L) {
        std::cerr << "Could not create Lua state.\n";
        SDL_DestroyRenderer(renderer); SDL_DestroyWindow(window); SDL_Quit(); return 1;
    }
    luaL_openlibs(L);
    RegisterApi(L);
    if (luaL_dofile(L, "scripts/main.lua") != LUA_OK) {
        std::cerr << "Could not load scripts/main.lua: " << lua_tostring(L, -1) << '\n';
        lua_pop(L, 1); lua_close(L); SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(window); SDL_Quit(); return 1;
    }
    CallLua("OnStart");

    bool running = true;
    Uint64 last = SDL_GetPerformanceCounter();
    while (running) {
        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) running = false;
            if (event.type == SDL_KEYDOWN && event.key.keysym.scancode == SDL_SCANCODE_ESCAPE) running = false;
        }
        Uint64 now = SDL_GetPerformanceCounter();
        double dt = static_cast<double>(now - last) / SDL_GetPerformanceFrequency();
        last = now;
        if (dt > 0.05) dt = 0.05;

        UpdatePhysics(static_cast<float>(dt));
        SDL_SetRenderDrawColor(renderer, 18, 20, 35, 255);
        SDL_RenderClear(renderer);
        CallLua("OnUpdate", dt, true);
        DrawObjects();
        CallLua("OnDraw");
        SDL_RenderPresent(renderer);
    }

    lua_close(L);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}
