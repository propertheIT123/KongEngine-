-- Minimal Lua-side trigger scheduler.
Trigger = { timers = {}, enterCallbacks = {} }

function Trigger.After(seconds, callback)
    table.insert(Trigger.timers, { remaining = math.max(0, seconds), callback = callback })
end

function Trigger.Update(dt)
    for i = #Trigger.timers, 1, -1 do
        local timer = Trigger.timers[i]
        timer.remaining = timer.remaining - dt
        if timer.remaining <= 0 then
            table.remove(Trigger.timers, i)
            local ok, err = pcall(timer.callback)
            if not ok then Kong.Log("Trigger error: " .. tostring(err)) end
        end
    end
end

-- KongEngine 0.2 Extended: демонстрация 2D-платформера.
-- A/D или стрелки — движение; Space/W/Up — прыжок.
local player
local floor
local spike
local elapsed = 0
local grounded = false

local function overlaps(a, b)
    return a.x < b.x + b.w and a.x + a.w > b.x
       and a.y < b.y + b.h and a.y + a.h > b.y
end

function OnStart()
    Kong.Log("KongEngine 0.2 Extended started")
    floor = Kong.CreateObject("Floor", 0, 450, 2600, 90, 75, 85, 115, true, false)
    player = Kong.CreateObject("Player", 120, 390, 32, 32, 40, 220, 255, false, true)
    spike = Kong.CreateObject("Spike (placeholder)", 470, 418, 30, 32, 255, 70, 90, false, false)
    Kong.CreateObject("Platform", 340, 370, 130, 18, 110, 120, 155, true, false)
    Kong.CreateObject("Platform", 650, 330, 150, 18, 110, 120, 155, true, false)
    Trigger.After(2.0, function()
        Kong.Log("Timed trigger fired after 2 seconds")
    end)
end

function OnUpdate(dt)
    elapsed = elapsed + dt
    local obj = nil
    -- Object state query is intentionally kept minimal in this prototype.
    -- Player movement and jumping are controlled by velocity.
    if Kong.InputDown("LEFT") or Kong.InputDown("A") then
        Kong.SetVelocity(player, -230, 0)
    elseif Kong.InputDown("RIGHT") or Kong.InputDown("D") then
        Kong.SetVelocity(player, 230, 0)
    else
        Kong.SetVelocity(player, 0, 0)
    end

    if (Kong.InputDown("SPACE") or Kong.InputDown("W") or Kong.InputDown("UP")) and grounded then
        Kong.SetVelocity(player, 0, -560)
        grounded = false
    end

    -- Camera follows player with a basic world-coordinate approximation.
    -- Trigger updates happen here to remain deterministic.
    Trigger.Update(dt)
    -- Placeholder death/restart area for the demo.
    if elapsed > 0 then
        Kong.SetCameraX(math.max(0, elapsed * 30))
    end
end

function OnDraw()
    -- Small visual cue for the floor baseline; world objects are rendered by C++.
end
