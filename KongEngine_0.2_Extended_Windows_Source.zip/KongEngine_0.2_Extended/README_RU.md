# KongEngine 0.2 Extended — исходный проект для Windows

KongEngine — экспериментальный 2D-движок на C++17 с Lua-скриптами и SDL2.

## Что входит в этот архив
- Окно и игровой цикл на SDL2.
- Lua 5.4: загрузка `scripts/main.lua`, вызовы `OnStart`, `OnUpdate(dt)` и `OnDraw`.
- API Lua: `Kong.Log`, `Kong.InputDown`, `Kong.CreateObject`, `Kong.SetPosition`, `Kong.SetVelocity`, `Kong.SetColor`, `Kong.SetSolid`, `Kong.DestroyObject`, `Kong.DrawRect`.
- Простая физика платформера: гравитация и приземление на прямоугольные платформы.
- Камера, следующая за игроком по горизонтали.
- Простейшие триггеры по времени и пересечению объектов: `Trigger.After` и `Trigger.OnEnter`.
- Демонстрационный уровень с квадратным персонажем, платформами и шипами.

**Важно:** это исходный код прототипа, не готовый EXE и не готовый профессиональный редактор. APK и Android-порт в этой версии ещё не реализованы. Сборка требует установки зависимостей.

## Требования
- Windows 10/11 x64
- Visual Studio 2022 с workload **Desktop development with C++**
- CMake
- SDL2
- Lua 5.4
- Рекомендуется менеджер пакетов vcpkg

### Установка зависимостей через vcpkg
В Developer PowerShell for VS 2022:
```powershell
git clone https://github.com/microsoft/vcpkg.git C:\dev\vcpkg
C:\dev\vcpkg\bootstrap-vcpkg.bat
C:\dev\vcpkg\vcpkg.exe install sdl2 lua:x64-windows
```

### Сборка
В Developer PowerShell, из папки распакованного проекта:
```powershell
cmake -S . -B build -DCMAKE_TOOLCHAIN_FILE=C:/dev/vcpkg/scripts/buildsystems/vcpkg.cmake
cmake --build build --config Release
```

Запускать из корня проекта, чтобы скрипт нашёлся по относительному пути:
```powershell
.\build\Release\KongEngine.exe
```
Если Windows не находит SDL2.dll, скопируй её рядом с EXE. CMake попробует скопировать DLL автоматически для динамического SDL2-пакета.

## Управление демо
- A/D или стрелки влево/вправо — движение
- Space/W/стрелка вверх — прыжок
- Esc — выход

## Структура
- `engine/main.cpp` — ядро движка
- `scripts/main.lua` — пример игры
- `examples/trigger_examples.lua` — примеры триггеров
- `CMakeLists.txt` — конфигурация сборки
- `assets/` — папка ресурсов

## Ограничения прототипа
- Рисуются цветные прямоугольники; загрузчика текстур и графического редактора пока нет.
- Физика демонстрационная и не является точной физикой Geometry Dash.
- Коллизии рассчитаны на простые прямоугольные платформы.
- APK-сборщик, автономный упаковщик игр и редактор уровней ещё предстоит реализовать.
- Не запускай неизвестные Lua-скрипты: скрипты исполняются внутри процесса движка.

## Следующие задачи
Текстуры/спрайты, сохранение уровней, полноценный редактор, музыка и синхронизация, расширенные триггеры, профилирование, Android-порт.

## Лицензия
MIT. SDL2 и Lua распространяются по своим лицензиям.

### Примечание о триггерах
В текущем прототипе реализован Lua-планировщик `Trigger.After(seconds, callback)`. Триггеры столкновения, группы и визуальный редактор триггеров пока не завершены; они входят в дальнейшую разработку.
